<?php

if (!class_exists('TCPDF')) {
    require_once __DIR__.'/tcpdf_include.php';
}

class ArahanSiasatanPdf extends TCPDF
{
    protected $x0 = 14.7;
    protected $w0 = 180.4;
    protected $right = 195.1;

    public function __construct()
    {
        parent::__construct('P', 'mm', 'A4', true, 'UTF-8', false);

        $this->setPrintHeader(false);
        $this->setPrintFooter(true);

        $this->SetMargins(0, 0, 0);
        $this->SetAutoPageBreak(false, 0);
        $this->SetCellPadding(1.0);

        $this->SetCreator('GEMS 2.0');
        $this->SetAuthor('GEMS 2.0');
        $this->SetTitle('Borang Arahan Siasatan & Penyenggaraan Pembaikan');
    }

    public function Footer()
    {
        $this->SetDrawColor(0, 0, 0);
        $this->SetLineWidth(0.25);
        $this->Line(14.7, 282.5, 195.1, 282.5);

        $this->SetFont('helvetica', '', 8.5);
        $this->SetXY(150, 283.5);
        $this->Cell(45, 4, 'Halaman '.$this->getAliasNumPage().' / '.$this->getAliasNbPages(), 0, 0, 'R');
    }

    private function drawCell($x, $y, $w, $h, $text = '', $border = 1, $align = 'L', $style = '', $size = 8.2, $valign = 'M')
    {
        $this->SetFont('helvetica', $style, $size);
        $this->SetXY($x, $y);

        $this->MultiCell(
            $w,
            $h,
            $text,
            $border,
            $align,
            false,
            0,
            '',
            '',
            true,
            0,
            false,
            true,
            $h,
            $valign
        );
    }

    private function section($y, $title)
    {
        $this->SetLineWidth(0.35);
        $this->drawCell($this->x0, $y, $this->w0, 6.4, $title, 1, 'L', 'B', 8.7);
        $this->SetLineWidth(0.18);
    }

    private function fitImage($path, $x, $y, $w, $h)
    {
        if (!$path || !file_exists($path)) {
            return;
        }

        $info = getimagesize($path);
        if (!$info) {
            return;
        }

        [$iw, $ih] = $info;

        $ratio = min($w / $iw, $h / $ih);
        $nw = $iw * $ratio;
        $nh = $ih * $ratio;

        $ix = $x + (($w - $nw) / 2);
        $iy = $y + (($h - $nh) / 2);

        $this->Image($path, $ix, $iy, $nw, $nh, '', '', '', true, 300);
    }

    public function render(array $data)
    {
        $this->drawPageOne($data);
        $this->drawPhotoPages($data['photos'] ?? []);

        return $this;
    }

    private function drawPageOne(array $d)
    {
        $this->AddPage();

        $x = $this->x0;
        $w = $this->w0;

        $this->SetLineWidth(0.35);

        $this->drawCell($x, 11.7, $w, 10.1, 'JKR.PATA.F7/4', 1, 'R', 'B', 8.2);
        $this->drawCell($x, 21.8, $w, 4.5, 'BORANG ARAHAN SIASATAN & PENYENGGARAAN PEMBAIKAN', 1, 'C', 'B', 8.2);

        $this->drawCell($x, 26.3, 125.1, 9.1, 'Format Arahan Siasatan dan Penyenggaraan Pembaikan', 1, 'C', '', 8.2);

        $this->drawCell(139.8, 26.3, 20.1, 4.55, 'No. Ruj.', 1, 'L', 'B', 8.2);
        $this->drawCell(159.9, 26.3, 35.2, 4.55, $d['no_ruj'] ?? '', 1, 'L', '', 8.2);

        $this->drawCell(139.8, 30.85, 20.1, 4.55, 'Status', 1, 'L', 'B', 8.2);
        $this->drawCell(159.9, 30.85, 35.2, 4.55, $d['status'] ?? '', 1, 'L', '', 8.2);

        $this->section(35.4, 'A. ADUAN');

        $ay = 41.8;
        $rh = 4.55;

        $leftLabel = 28.0;
        $leftValue = 62.2;
        $rightLabel = 27.9;
        $rightValue = 62.3;

        $rowsA = [
            ['Nama Pengadu', $d['nama_pengadu'] ?? '', 'Jenis Kerja', $d['jenis_kerja'] ?? ''],
            ['Tarikh & Masa', $d['tarikh_aduan'] ?? '', 'Kategori Kerja', $d['kategori_kerja'] ?? ''],
            ['No. Telefon', $d['no_telefon'] ?? '', 'Keutamaan Kerja', $d['keutamaan_kerja'] ?? ''],
            ['Keterangan', $d['keterangan_aduan'] ?? '', 'Lokasi', $d['lokasi'] ?? ''],
            ['No. Aset', $d['no_aset'] ?? '', 'Nama Aset', $d['nama_aset'] ?? ''],
        ];

        foreach ($rowsA as $i => $r) {
            $y = $ay + ($i * $rh);

            $this->drawCell(14.7, $y, $leftLabel, $rh, $r[0], 1, 'L', 'B');
            $this->drawCell(42.7, $y, $leftValue, $rh, $r[1], 1, 'L');

            $this->drawCell(104.9, $y, $rightLabel, $rh, $r[2], 1, 'L', 'B');
            $this->drawCell(132.8, $y, $rightValue, $rh, $r[3], 1, 'L');
        }

        $this->section(64.5, 'B. ARAHAN SIASATAN');

        $this->drawCell(14.7, 71.1, 22.9, 8.0, 'Diterima Oleh', 1, 'L', 'B');
        $this->drawCell(37.6, 71.1, 35.1, 8.0, $d['diterima_oleh'] ?? '', 1, 'L');

        $this->drawCell(72.7, 71.1, 29.1, 8.0, 'Ditugaskan Kepada', 1, 'L', 'B');
        $this->drawCell(101.8, 71.1, 35.0, 8.0, $d['ditugaskan_kepada'] ?? '', 1, 'L');

        $this->drawCell(136.8, 71.1, 23.1, 8.0, 'Tarikh / Masa', 1, 'L', 'B');
        $this->drawCell(159.9, 71.1, 35.2, 8.0, $d['tarikh_arahan'] ?? '', 1, 'L');

        $this->drawCell(14.7, 79.1, 58.0, 4.6, '', 1, 'L');
        $this->drawCell(72.7, 79.1, 29.1, 4.6, 'No. Utk Dihubungi', 1, 'L', 'B');
        $this->drawCell(101.8, 79.1, 35.0, 4.6, $d['no_dihubungi'] ?? '', 1, 'L');
        $this->drawCell(136.8, 79.1, 58.3, 4.6, '', 1, 'L');

        $this->drawCell(14.7, 83.7, 22.9, 4.6, 'Keterangan', 1, 'L', 'B');
        $this->drawCell(37.6, 83.7, 157.5, 4.6, $d['keterangan_arahan'] ?? '', 1, 'L');

        $this->drawCell(14.7, 88.3, 22.9, 9.0, 'Tarikh & Masa', 1, 'L', 'B');
        $this->drawCell(37.6, 88.3, 71.1, 9.0, $d['tarikh_tandatangan_pengadu'] ?? '', 1, 'L');

        $this->drawCell(108.7, 88.3, 34.2, 9.0, 'Tandatangan Pengadu', 1, 'L', 'B');
        $this->drawCell(142.9, 88.3, 52.2, 9.0, '', 1, 'C');
        $this->fitImage($d['sign_pengadu'] ?? null, 150, 88.7, 30, 8);

        $this->drawCell(14.7, 97.3, 94.0, 4.5, '', 1);
        $this->drawCell(108.7, 97.3, 34.2, 4.5, 'Cap Nama & Jawatan', 1, 'L', 'B');
        $this->drawCell(142.9, 97.3, 52.2, 4.5, $d['cap_pengadu'] ?? '', 1, 'C', 'I', 7.7);

        $this->section(101.8, 'C. BUTIRAN ALAT GANTI');

        $this->drawCell(14.7, 108.3, 24.0, 8.0, 'No. Alat Ganti', 1, 'C', 'B');
        $this->drawCell(38.7, 108.3, 70.0, 8.0, 'Keterangan', 1, 'C', 'B');
        $this->drawCell(108.7, 108.3, 20.2, 8.0, "Jenis Isu /\n(D/I)", 1, 'C', 'B');
        $this->drawCell(128.9, 108.3, 20.0, 8.0, 'Unit Bahan', 1, 'C', 'B');
        $this->drawCell(148.9, 108.3, 23.0, 8.0, "Kuantiti\nDigunakan", 1, 'C', 'B');
        $this->drawCell(171.9, 108.3, 23.2, 8.0, "Kuantiti\nDikembalikan", 1, 'C', 'B');

        $partsY = 116.3;
        $partsRowH = 4.6;
        $partsRows = $d['parts'] ?? [[]];
        if (empty($partsRows)) {
            $partsRows = [[]];
        }
        $partLimit = min(count($partsRows), 1);
        for ($i = 0; $i < $partLimit; $i++) {
            $part = $partsRows[$i];
            $y = $partsY + ($i * $partsRowH);
            $this->drawCell(14.7, $y, 24.0, $partsRowH, $part['no'] ?? '', 1, 'C');
            $this->drawCell(38.7, $y, 70.0, $partsRowH, $part['keterangan'] ?? '', 1, 'L');
            $this->drawCell(108.7, $y, 20.2, $partsRowH, $part['jenis'] ?? '', 1, 'C');
            $this->drawCell(128.9, $y, 20.0, $partsRowH, $part['unit'] ?? '', 1, 'C');
            $this->drawCell(148.9, $y, 23.0, $partsRowH, $part['digunakan'] ?? '', 1, 'C');
            $this->drawCell(171.9, $y, 23.2, $partsRowH, $part['dikembalikan'] ?? '', 1, 'C');
        }

        $this->drawCell(14.7, 120.9, 180.4, 4.5, '** D = Direct Issue, I = Inventory', 1, 'L', 'I');

        $this->section(125.4, 'D. BUTIRAN KERJA');

        $this->drawCell(14.7, 132.0, 60.0, 4.5, 'Nama Pekerja', 1, 'C', 'B');
        $this->drawCell(74.7, 132.0, 30.2, 4.5, 'No. Pekerja', 1, 'C', 'B');
        $this->drawCell(104.9, 132.0, 34.9, 4.5, 'Tarikh & Masa Mula', 1, 'C', 'B');
        $this->drawCell(139.8, 132.0, 35.2, 4.5, 'Tarikh & Masa Tamat', 1, 'C', 'B');
        $this->drawCell(175.0, 132.0, 20.1, 4.5, 'Tempoh', 1, 'C', 'B');

        $this->drawCell(14.7, 136.5, 60.0, 4.6, $d['nama_pekerja'] ?? '', 1, 'L');
        $this->drawCell(74.7, 136.5, 30.2, 4.6, $d['no_pekerja'] ?? '', 1, 'C');
        $this->drawCell(104.9, 136.5, 34.9, 4.6, $d['kerja_mula'] ?? '', 1, 'C');
        $this->drawCell(139.8, 136.5, 35.2, 4.6, $d['kerja_tamat'] ?? '', 1, 'C');
        $this->drawCell(175.0, 136.5, 20.1, 4.6, $d['tempoh_kerja'] ?? '', 1, 'C');

        $this->section(141.1, 'E. TINDAKAN PEMBAIKAN / PENCEGAHAN');

        $this->drawCell(14.7, 147.6, 27.0, 4.5, 'Tindakan', 1, 'L', 'B');
        $this->drawCell(41.7, 147.6, 153.4, 4.5, $d['tindakan'] ?? '', 1, 'L');

        $this->drawCell(14.7, 152.1, 28.0, 4.5, 'Tarikh & Masa Mula', 1, 'L', 'B');
        $this->drawCell(42.7, 152.1, 66.0, 4.5, $d['tindakan_mula'] ?? '', 1, 'L');

        $this->drawCell(108.7, 152.1, 34.2, 4.5, 'Tarikh & Masa Siap', 1, 'L', 'B');
        $this->drawCell(142.9, 152.1, 26.0, 4.5, $d['tindakan_siap'] ?? '', 1, 'L');

        $this->drawCell(168.9, 152.1, 26.2, 4.5, 'Tempoh', 1, 'L', 'B');
        $this->drawCell(182.8, 152.1, 12.3, 4.5, $d['tempoh_tindakan'] ?? '', 1, 'C');

        $this->drawCell(14.7, 156.6, 94.0, 9.0, '', 1);
        $this->drawCell(108.7, 156.6, 34.2, 9.0, 'Tandatangan', 1, 'L', 'B');
        $this->drawCell(142.9, 156.6, 52.2, 9.0, '', 1, 'C');
        $this->fitImage($d['sign_technician'] ?? null, 150, 157, 28, 8);

        $this->drawCell(14.7, 165.6, 94.0, 8.1, '', 1);
        $this->drawCell(108.7, 165.6, 34.2, 8.1, 'Cap Nama & Jawatan', 1, 'L', 'B');
        $this->drawCell(142.9, 165.6, 52.2, 8.1, $d['cap_technician'] ?? '', 1, 'C', 'I', 7.5);

        $this->section(173.7, 'F. JIKA LUAR SKOP KERJA / TEMPOH TANGGUNGAN KECACATAN');

        $fRows = [
            ['Nama Kontraktor', $d['nama_kontraktor'] ?? ''],
            ['Lantikan Mula Kerja', $d['lantikan_mula_kerja'] ?? ''],
            ['Tarikh Siap Kerja', $d['tarikh_siap_kerja'] ?? ''],
            ['Kos Akhir', $d['kos_akhir'] ?? ''],
        ];

        $fy = 180.2;
        foreach ($fRows as $i => $r) {
            $y = $fy + ($i * 4.55);
            $this->drawCell(14.7, $y, 28.0, 4.55, $r[0], 1, 'L', 'B');
            $this->drawCell(42.7, $y, 152.4, 4.55, $r[1], 1, 'L');
        }

        $this->section(198.4, 'G. PERAKUAN KERJA SIAP');

        $this->drawCell(14.7, 204.9, 45.0, 9.1, 'Tandatangan', 1, 'L', 'B');
        $this->drawCell(59.7, 204.9, 45.2, 9.1, '', 1, 'C');
        $this->fitImage($d['sign_pegawai_penyelia'] ?? null, 65, 205.2, 30, 8);

        $this->drawCell(104.9, 204.9, 45.0, 9.1, 'Tandatangan', 1, 'L', 'B');
        $this->drawCell(149.9, 204.9, 45.2, 9.1, '', 1, 'C');
        $this->fitImage($d['sign_pengadu_kerja_siap'] ?? null, 158, 205.2, 28, 8);

        $this->drawCell(14.7, 214.0, 45.0, 8.0, '', 1);
        $this->drawCell(59.7, 214.0, 45.2, 8.0, "Pengesahan Oleh Pegawai\nPenyelia", 1, 'C', 'B', 7.8);

        $this->drawCell(104.9, 214.0, 45.0, 8.0, '', 1);
        $this->drawCell(149.9, 214.0, 45.2, 8.0, "Pengesahan Oleh Pihak\nPengadu (Jika Berkenaan)", 1, 'C', 'B', 7.8);

        $this->drawCell(14.7, 222.0, 45.0, 8.0, 'Cap Nama & Jawatan', 1, 'L', 'B');
        $this->drawCell(59.7, 222.0, 45.2, 8.0, $d['cap_pegawai_penyelia'] ?? '', 1, 'C', 'I', 7.5);

        $this->drawCell(104.9, 222.0, 45.0, 8.0, 'Cap Nama & Jawatan', 1, 'L', 'B');
        $this->drawCell(149.9, 222.0, 45.2, 8.0, $d['cap_pengadu_kerja_siap'] ?? '', 1, 'C', 'I', 7.5);

        $this->drawCell(14.7, 230.0, 45.0, 4.6, 'Tarikh & Masa', 1, 'L', 'B');
        $this->drawCell(59.7, 230.0, 45.2, 4.6, $d['tarikh_pegawai_penyelia'] ?? '', 1, 'C');

        $this->drawCell(104.9, 230.0, 45.0, 4.6, 'Tarikh & Masa', 1, 'L', 'B');
        $this->drawCell(149.9, 230.0, 45.2, 4.6, $d['tarikh_pengadu_kerja_siap'] ?? '', 1, 'C');

        $this->drawCell(104.9, 234.6, 45.0, 8.0, 'Tandatangan', 1, 'L', 'B');
        $this->drawCell(149.9, 234.6, 45.2, 8.0, '', 1);
        $this->fitImage($d['sign_operasi_fasiliti'] ?? null, 158, 235.0, 28, 8);

        $this->drawCell(104.9, 242.6, 45.0, 8.0, '', 1);
        $this->drawCell(149.9, 242.6, 45.2, 8.0, "Pengesahan Oleh Pegawai\nOperasi Fasiliti", 1, 'C', 'B', 7.8);

        $this->drawCell(104.9, 250.6, 45.0, 8.0, 'Cap Nama & Jawatan', 1, 'L', 'B');
        $this->drawCell(149.9, 250.6, 45.2, 8.0, $d['cap_operasi_fasiliti'] ?? '', 1, 'C', 'I', 7.5);

        $this->drawCell(104.9, 258.6, 45.0, 5.7, 'Tarikh & Masa', 1, 'L', 'B');
        $this->drawCell(149.9, 258.6, 45.2, 5.7, $d['tarikh_operasi_fasiliti'] ?? '', 1, 'C');

        $this->drawCell(14.7, 234.6, 90.2, 29.7, '', 1);
    }

    private function drawPhotoPages(array $photos)
    {
        if (empty($photos)) {
            return;
        }

        $flatItems = [];
        foreach ($photos as $group) {
            $title = $group['title'] ?? '';
            $items = $group['items'] ?? [];
            foreach ($items as $itemIndex => $item) {
                $flatItems[] = [
                    'title' => $itemIndex === 0 ? $title : '',
                    'item' => $item,
                ];
            }
        }

        if (empty($flatItems)) {
            return;
        }

        $x = 14.7;
        $w = 180.4;
        $leftW = 95.0;
        $rightW = $w - $leftW;

        $pageTwoSlots = [
            ['titleY' => 19.9,  'rowY' => 26.0,  'rowH' => 65.6],
            ['titleY' => 100.1, 'rowY' => 106.1, 'rowH' => 65.5],
            ['titleY' => 180.2, 'rowY' => 186.2, 'rowH' => 65.5],
        ];

        $pageThreeSlots = [
            ['titleY' => null,  'rowY' => 11.7,  'rowH' => 65.1],
            ['titleY' => null,  'rowY' => 76.8,  'rowH' => 65.7],
            ['titleY' => 150.9, 'rowY' => 156.9, 'rowH' => 65.7],
        ];

        $this->AddPage();
        $slotIndex = 0;
        $slots = $pageTwoSlots;

        foreach ($flatItems as $entry) {
            if ($slotIndex >= count($slots)) {
                $this->AddPage();
                $slots = ($slots === $pageTwoSlots) ? $pageThreeSlots : $pageTwoSlots;
                $slotIndex = 0;
            }

            $slot = $slots[$slotIndex];

            if (!empty($entry['title']) && $slot['titleY'] !== null) {
                $this->SetFont('helvetica', '', 11.5);
                $this->drawCell($x, $slot['titleY'], $w, 6.1, $entry['title'], 1, 'L', '', 11.5);
            }

            $this->drawPhotoRow(
                $entry['item'],
                $x,
                $slot['rowY'],
                $leftW,
                $rightW,
                $slot['rowH']
            );

            $slotIndex++;
        }
    }

    private function drawPhotoRow(array $item, $x, $y, $leftW, $rightW, $rowH)
    {
        $this->drawCell($x, $y, $leftW, $rowH, '', 1);
        $this->drawCell($x + $leftW, $y, $rightW, $rowH, '', 1);

        $this->fitImage(
            $item['image'] ?? null,
            $x + 20,
            $y + 4,
            55,
            $rowH - 8
        );

        $text = 'Keterangan : '.($item['keterangan'] ?? '')."\n"
            .'Masa Diambil : '.($item['masa'] ?? '')."\n"
            .'Longitude : '.($item['longitude'] ?? '')."\n"
            .'Latitude : '.($item['latitude'] ?? '');

        $this->drawCell($x + $leftW + 2, $y + 5, $rightW - 4, 25, $text, 0, 'L', '', 9.5, 'T');
    }
}
